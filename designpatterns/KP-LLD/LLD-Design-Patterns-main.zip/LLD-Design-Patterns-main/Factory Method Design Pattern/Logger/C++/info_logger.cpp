#include "info_logger.hpp"

void InfoLogger::log(const string& msg) {
    cout<<"INFO : "<<msg<<endl;
}