#pragma once

#include <iostream>

using namespace std;

enum class LogLevel {
    DEBUG,
    INFO,
    ERROR
};