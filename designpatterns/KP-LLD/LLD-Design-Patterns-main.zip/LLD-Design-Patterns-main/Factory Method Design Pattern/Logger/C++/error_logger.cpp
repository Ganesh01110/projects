#include "error_logger.hpp"

void ErrorLogger::log(const string& msg) {
    cout<<"ERROR : "<<msg<<endl;
}