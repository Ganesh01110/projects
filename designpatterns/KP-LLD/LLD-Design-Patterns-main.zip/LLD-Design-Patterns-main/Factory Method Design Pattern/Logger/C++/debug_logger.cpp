#include "debug_logger.hpp"

void DebugLogger::log(const string &msg)
{
    cout << "DEBUG : " << msg << endl;
}