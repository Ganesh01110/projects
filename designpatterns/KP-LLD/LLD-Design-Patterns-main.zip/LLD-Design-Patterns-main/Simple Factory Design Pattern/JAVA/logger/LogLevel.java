package logger;

public enum LogLevel {
    DEBUG, INFO, ERROR
}

