package logger;

public interface ILogger {
    void log (String msg);
}
